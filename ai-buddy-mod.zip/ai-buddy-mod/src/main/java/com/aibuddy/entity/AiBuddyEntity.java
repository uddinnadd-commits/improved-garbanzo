package com.aibuddy.entity;

import com.aibuddy.AiBuddyConfig;
import com.aibuddy.AiBuddyMod;
import com.aibuddy.ai.Actions;
import com.aibuddy.ai.BuddyBrain;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The AI-controlled player-like buddy. The "mind" talks to the LLM; this class
 * executes the resulting action queue (walk, mine, build, eat, fight, craft...).
 */
public class AiBuddyEntity extends PathfinderMob {
    public final BuddyBrain mind;

    private final SimpleContainer inventory = new SimpleContainer(36);
    private final ArrayDeque<Actions.Action> queue = new ArrayDeque<>();
    private final List<String> results = new ArrayList<>();
    private Actions.Action current;
    private UUID ownerId;
    private int food = 20;
    private int foodTimer = 0;
    private boolean following = false;
    private boolean thinking = false;

    public AiBuddyEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.mind = new BuddyBrain(this);
        setPersistenceRequired();
        setCanPickUpLoot(false);
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        if (getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
        if (!level.isClientSide) refreshName();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    // ------------------------------------------------------------------ owner / name

    public UUID getOwnerId() { return ownerId; }

    public void setOwner(UUID id) { this.ownerId = id; }

    public Player getBuddyOwner() {
        return ownerId == null ? null : level().getPlayerByUUID(ownerId);
    }

    public void setThinking(boolean t) {
        this.thinking = t;
        refreshName();
    }

    public void refreshName() {
        String n = AiBuddyConfig.BUDDY_NAME.get();
        setCustomName(Component.literal(thinking ? n + " (thinking...)" : n));
        setCustomNameVisible(true);
    }

    public int getFood() { return food; }

    public boolean isFollowing() { return following; }

    public void setFollowing(boolean f) { this.following = f; }

    // ------------------------------------------------------------------ action queue

    public void setPlan(List<Actions.Action> actions) {
        if (actions.isEmpty()) return;
        cancelPlan();
        following = false;
        queue.addAll(actions);
    }

    private void cancelPlan() {
        if (current != null) {
            current.onEnd(this);
            current = null;
        }
        queue.clear();
    }

    public void stopAll() {
        cancelPlan();
        following = false;
        getNavigation().stop();
        mind.cancel();
    }

    public boolean isIdle() { return current == null && queue.isEmpty(); }

    public String describeCurrent() {
        return current == null ? "idle" : current.name();
    }

    public int queuedActions() { return queue.size() + (current == null ? 0 : 1); }

    public void addResult(String s) {
        if (results.size() > 40) results.remove(0);
        results.add(s);
    }

    public String drainResults() {
        if (results.isEmpty()) return "";
        String s = String.join("\n", results);
        results.clear();
        return s;
    }

    // ------------------------------------------------------------------ ticking

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        serverTick();
    }

    private void serverTick() {
        if (ownerId != null && tickCount % 20 == 0) AiBuddyMod.BUDDIES.put(ownerId, this);

        if (AiBuddyConfig.HUNGER.get()) {
            if (++foodTimer >= 1200) {
                foodTimer = 0;
                if (food > 0) food--;
            }
            if (tickCount % 80 == 0) {
                if (food >= 18 && getHealth() < getMaxHealth()) heal(1.0F);
                else if (food <= 0 && getHealth() > 10.0F) hurt(damageSources().starve(), 1.0F);
            }
        } else if (tickCount % 80 == 0 && getHealth() < getMaxHealth()) {
            heal(1.0F);
        }

        if (tickCount % 5 == 0) pickupItems();

        // Fight back while busy with another job
        if (current != null && !(current instanceof Actions.Attack) && AiBuddyConfig.AUTO_DEFEND.get()
                && tickCount % 10 == 0 && nearestHostile(4.0D) != null) {
            Actions.Attack atk = new Actions.Attack("nearest_hostile", 5);
            atk.silent = true;
            queue.addFirst(current);
            current = atk;
        }

        if (current == null) current = queue.pollFirst();

        if (current != null) {
            boolean done;
            try {
                done = current.tick(this);
            } catch (Exception ex) {
                current.result = "FAILED - internal error: " + ex;
                done = true;
            }
            if (done) {
                if (!current.silent) addResult(current.name() + ": " + current.result);
                current.onEnd(this);
                current = null;
            }
        } else {
            idleBehavior();
        }

        if (current == null && queue.isEmpty()) mind.tickIdle();
    }

    private void idleBehavior() {
        if (AiBuddyConfig.HUNGER.get() && food <= 10 && tickCount % 40 == 0 && findFoodItem(null) != null) {
            Actions.Eat eat = new Actions.Eat(null);
            eat.silent = true;
            queue.addFirst(eat);
            return;
        }
        if (AiBuddyConfig.AUTO_DEFEND.get() && tickCount % 10 == 0 && nearestHostile(7.0D) != null) {
            Actions.Attack atk = new Actions.Attack("nearest_hostile", 5);
            atk.silent = true;
            queue.addFirst(atk);
            return;
        }
        if (following) {
            Player o = getBuddyOwner();
            if (o != null) {
                double d = distanceToSqr(o);
                if (d > 400.0D) {
                    teleportNear(o.blockPosition());
                } else if (d > 16.0D) {
                    if (tickCount % 10 == 0 || getNavigation().isDone()) getNavigation().moveTo(o, 1.2D);
                } else if (d < 9.0D) {
                    getNavigation().stop();
                }
            }
        }
    }

    public LivingEntity nearestHostile(double range) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(range),
                x -> x != this && x.isAlive() && isValidHostile(x))) {
            double d = distanceToSqr(e);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    public static boolean isValidHostile(LivingEntity e) {
        return e instanceof Enemy && !(e instanceof EnderMan) && !(e instanceof ZombifiedPiglin);
    }

    // ------------------------------------------------------------------ inventory helpers

    public SimpleContainer getBuddyInventory() { return inventory; }

    public void addToInventory(ItemStack stack) {
        if (stack.isEmpty()) return;
        ItemStack rest = inventory.addItem(stack.copy());
        if (!rest.isEmpty()) spawnAtLocation(rest);
    }

    public int countItem(Item item) {
        int n = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public ItemStack removeItem(Item item, int count) {
        return inventory.removeItemType(item, count);
    }

    public Map<String, Integer> summarizeInventory() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            m.merge(BuiltInRegistries.ITEM.getKey(s.getItem()).getPath(), s.getCount(), Integer::sum);
        }
        return m;
    }

    private void pickupItems() {
        for (ItemEntity ie : level().getEntitiesOfClass(ItemEntity.class, getBoundingBox().inflate(1.5D, 0.5D, 1.5D))) {
            if (ie.isRemoved() || ie.getPersistentData().getBoolean("aibuddy_given")) continue;
            ItemStack stack = ie.getItem();
            if (stack.isEmpty()) continue;
            ItemStack rest = inventory.addItem(stack.copy());
            if (rest.getCount() == stack.getCount()) continue; // nothing fit
            level().playSound(null, ie.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.2F, 1.4F);
            if (rest.isEmpty()) ie.discard();
            else ie.setItem(rest);
        }
    }

    public int[] planIngredients(List<Ingredient> ingredients) {
        int[] used = new int[inventory.getContainerSize()];
        for (Ingredient ing : ingredients) {
            if (ing.isEmpty()) continue;
            boolean found = false;
            for (int i = 0; i < used.length; i++) {
                ItemStack s = inventory.getItem(i);
                if (!s.isEmpty() && used[i] < s.getCount() && ing.test(s)) {
                    used[i]++;
                    found = true;
                    break;
                }
            }
            if (!found) return null;
        }
        return used;
    }

    public void consumeUsed(int[] used) {
        for (int i = 0; i < used.length; i++) {
            if (used[i] > 0) inventory.getItem(i).shrink(used[i]);
        }
    }

    // ------------------------------------------------------------------ hands / tools

    public void setHand(ItemStack stack) {
        ItemStack c = stack.copy();
        if (!c.isEmpty()) c.setCount(1);
        setItemSlot(EquipmentSlot.MAINHAND, c);
    }

    public boolean equipByName(String name) {
        String want = name.toLowerCase(Locale.ROOT).replace("minecraft:", "");
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            String path = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
            if (path.equals(want) || path.contains(want)) {
                setHand(s);
                return true;
            }
        }
        return false;
    }

    public void equipBestTool(BlockState state) {
        ItemStack best = ItemStack.EMPTY;
        float bs = 1.0F;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            float sp = s.getDestroySpeed(state);
            if (sp > bs) { bs = sp; best = s; }
        }
        setHand(best);
    }

    public void equipBestWeapon() {
        ItemStack best = ItemStack.EMPTY;
        double bs = 0.0D;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            double dmg = 0.0D;
            for (var mod : s.getAttributeModifiers(EquipmentSlot.MAINHAND).get(Attributes.ATTACK_DAMAGE)) {
                dmg += mod.getAmount();
            }
            if (dmg > bs) { bs = dmg; best = s; }
        }
        setHand(best);
    }

    // ------------------------------------------------------------------ food

    /** name == null picks the best safe food; otherwise a food whose id contains name. */
    public Item findFoodItem(String name) {
        Item best = null;
        int bn = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            Item it = s.getItem();
            FoodProperties fp = it.getFoodProperties();
            if (!it.isEdible() || fp == null) continue;
            String path = BuiltInRegistries.ITEM.getKey(it).getPath();
            if (name != null) {
                if (path.contains(name.toLowerCase(Locale.ROOT).replace("minecraft:", ""))) return it;
                continue;
            }
            if (!fp.getEffects().isEmpty()) continue; // skip rotten flesh, spider eyes, etc.
            if (fp.getNutrition() > bn) { bn = fp.getNutrition(); best = it; }
        }
        return best;
    }

    public boolean eatOne(Item item) {
        FoodProperties fp = item.getFoodProperties();
        if (fp == null || removeItem(item, 1).isEmpty()) return false;
        food = Math.min(20, food + fp.getNutrition());
        heal(fp.getNutrition() / 2.0F);
        level().playSound(null, blockPosition(), SoundEvents.PLAYER_BURP, SoundSource.NEUTRAL, 0.5F, 1.0F);
        return true;
    }

    // ------------------------------------------------------------------ world actions

    /** Mines a block like a player would: drops go into the inventory. */
    public void mineBlock(BlockPos pos) {
        if (!(level() instanceof ServerLevel sl)) return;
        BlockState st = sl.getBlockState(pos);
        if (st.isAir()) return;
        List<ItemStack> drops = Block.getDrops(st, sl, pos, sl.getBlockEntity(pos), this, getMainHandItem());
        sl.destroyBlock(pos, false, this);
        for (ItemStack d : drops) addToInventory(d);
    }

    public void clearBlock(BlockPos pos) {
        if (AiBuddyConfig.REQUIRE_MATERIALS.get()) {
            mineBlock(pos);
        } else {
            level().destroyBlock(pos, false, this);
        }
    }

    public boolean isStandable(BlockPos feet) {
        Level l = level();
        if (!l.isLoaded(feet)) return false;
        BlockState f = l.getBlockState(feet);
        BlockState h = l.getBlockState(feet.above());
        BlockState g = l.getBlockState(feet.below());
        return f.getCollisionShape(l, feet).isEmpty()
                && h.getCollisionShape(l, feet.above()).isEmpty()
                && f.getFluidState().isEmpty()
                && h.getFluidState().isEmpty()
                && g.isFaceSturdy(l, feet.below(), Direction.UP)
                && !g.is(Blocks.MAGMA_BLOCK);
    }

    /** Teleports to the closest safe standing spot near target (never inside the target cell). */
    public boolean teleportNear(BlockPos target) {
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -4; dy <= 4; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos p = target.offset(dx, dy, dz);
                    if (p.equals(target) || p.above().equals(target)) continue;
                    if (!isStandable(p)) continue;
                    double d = p.distSqr(target);
                    if (d < bd) { bd = d; best = p; }
                }
            }
        }
        if (best == null) return false;
        getNavigation().stop();
        moveTo(best.getX() + 0.5D, best.getY(), best.getZ() + 0.5D, getYRot(), getXRot());
        setDeltaMovement(0, 0, 0);
        fallDistance = 0;
        return true;
    }

    public void dropInventory() {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty()) spawnAtLocation(s.copy());
            inventory.setItem(i, ItemStack.EMPTY);
        }
    }

    // ------------------------------------------------------------------ interaction / death / save

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (ownerId == null) ownerId = player.getUUID();
        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty()) {
            int before = held.getCount();
            ItemStack rest = inventory.addItem(held.copy());
            int moved = before - rest.getCount();
            if (moved > 0) {
                String nm = held.getHoverName().getString();
                if (!player.getAbilities().instabuild) held.shrink(moved);
                player.sendSystemMessage(Component.literal("Gave " + moved + " x " + nm + " to " + AiBuddyConfig.BUDDY_NAME.get()));
            } else {
                player.sendSystemMessage(Component.literal(AiBuddyConfig.BUDDY_NAME.get() + "'s inventory is full."));
            }
        } else {
            player.sendSystemMessage(Component.literal(AiBuddyConfig.BUDDY_NAME.get() + " carries: " + summarizeInventory()
                    + " | health " + (int) getHealth() + "/" + (int) getMaxHealth() + " food " + food + "/20"));
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && getServer() != null) {
            mind.say("Ouch... I died at " + blockPosition().toShortString() + ". My stuff dropped there.");
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        dropInventory();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerId != null) tag.putUUID("BuddyOwner", ownerId);
        tag.putInt("BuddyFood", food);
        ListTag list = new ListTag();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.isEmpty()) continue;
            CompoundTag t = new CompoundTag();
            t.putByte("Slot", (byte) i);
            s.save(t);
            list.add(t);
        }
        tag.put("BuddyInv", list);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("BuddyOwner")) ownerId = tag.getUUID("BuddyOwner");
        if (tag.contains("BuddyFood")) food = tag.getInt("BuddyFood");
        ListTag list = tag.getList("BuddyInv", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            int slot = t.getByte("Slot") & 255;
            if (slot < inventory.getContainerSize()) inventory.setItem(slot, ItemStack.of(t));
        }
        if (!level().isClientSide) refreshName();
    }
}
