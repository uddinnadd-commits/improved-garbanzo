package com.aibuddy;

import com.aibuddy.command.AiCommand;
import com.aibuddy.entity.AiBuddyEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AiBuddyMod.MODID)
public class ForgeEvents {

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        String raw = event.getRawText();
        String prefix = AiBuddyConfig.CHAT_PREFIX.get();
        if (prefix.isEmpty() || raw.length() <= prefix.length()
                || !raw.regionMatches(true, 0, prefix, 0, prefix.length())) {
            return;
        }
        String msg = raw.substring(prefix.length()).trim();
        if (msg.isEmpty()) return;
        ServerPlayer player = event.getPlayer();
        if (player.getServer() == null) return;
        player.getServer().execute(() -> {
            AiBuddyEntity buddy = AiBuddyMod.findBuddy(player, true);
            if (buddy == null) {
                player.sendSystemMessage(Component.literal("You don't have an AI buddy yet. Use /ai spawn (or the AI Buddy spawn egg)."));
                return;
            }
            buddy.mind.ask(player, msg);
        });
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent event) {
        AiCommand.register(event.getDispatcher());
    }
}
