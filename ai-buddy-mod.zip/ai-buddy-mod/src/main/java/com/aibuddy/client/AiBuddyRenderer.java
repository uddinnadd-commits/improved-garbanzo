package com.aibuddy.client;

import com.aibuddy.entity.AiBuddyEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class AiBuddyRenderer extends HumanoidMobRenderer<AiBuddyEntity, HumanoidModel<AiBuddyEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("textures/entity/player/wide/steve.png");

    public AiBuddyRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(AiBuddyEntity entity) {
        return TEXTURE;
    }
}
