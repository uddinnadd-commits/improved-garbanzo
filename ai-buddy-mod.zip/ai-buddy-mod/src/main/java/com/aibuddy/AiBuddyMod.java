package com.aibuddy;

import com.aibuddy.entity.AiBuddyEntity;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(AiBuddyMod.MODID)
public class AiBuddyMod {
    public static final String MODID = "aibuddy";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<AiBuddyEntity>> BUDDY = ENTITIES.register("ai_buddy",
            () -> EntityType.Builder.<AiBuddyEntity>of((type, level) -> new AiBuddyEntity(type, level), MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("ai_buddy"));

    public static final RegistryObject<Item> BUDDY_EGG = ITEMS.register("ai_buddy_spawn_egg",
            () -> new ForgeSpawnEggItem(BUDDY, 0x3A86FF, 0xFFFFFF, new Item.Properties()));

    /** owner UUID -> that player's buddy (filled in by the entity while it ticks). */
    public static final Map<UUID, AiBuddyEntity> BUDDIES = new ConcurrentHashMap<>();

    public AiBuddyMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AiBuddyConfig.SPEC);
    }

    /** Finds the buddy that belongs to this player. With claim=true an unowned buddy (spawn egg) nearby is adopted. */
    public static AiBuddyEntity findBuddy(ServerPlayer p, boolean claim) {
        AiBuddyEntity e = BUDDIES.get(p.getUUID());
        if (e != null && !e.isRemoved() && e.isAlive()) return e;
        BUDDIES.remove(p.getUUID());
        AABB box = p.getBoundingBox().inflate(128);
        for (AiBuddyEntity b : p.serverLevel().getEntitiesOfClass(AiBuddyEntity.class, box)) {
            if (b.isAlive() && p.getUUID().equals(b.getOwnerId())) {
                BUDDIES.put(p.getUUID(), b);
                return b;
            }
        }
        if (claim) {
            for (AiBuddyEntity b : p.serverLevel().getEntitiesOfClass(AiBuddyEntity.class, box)) {
                if (b.isAlive() && b.getOwnerId() == null) {
                    b.setOwner(p.getUUID());
                    BUDDIES.put(p.getUUID(), b);
                    return b;
                }
            }
        }
        return null;
    }
}
