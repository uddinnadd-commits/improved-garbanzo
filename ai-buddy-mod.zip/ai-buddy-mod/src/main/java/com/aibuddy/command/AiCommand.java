package com.aibuddy.command;

import com.aibuddy.AiBuddyConfig;
import com.aibuddy.AiBuddyMod;
import com.aibuddy.entity.AiBuddyEntity;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public final class AiCommand {
    private AiCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("ai")
                .then(Commands.literal("spawn").executes(c -> spawn(c.getSource())))
                .then(Commands.literal("dismiss").executes(c -> dismiss(c.getSource())))
                .then(Commands.literal("come").executes(c -> come(c.getSource())))
                .then(Commands.literal("stop").executes(c -> stop(c.getSource())))
                .then(Commands.literal("status").executes(c -> status(c.getSource())))
                .then(Commands.literal("forget").executes(c -> forget(c.getSource())))
                .then(Commands.literal("ask")
                        .then(Commands.argument("message", StringArgumentType.greedyString())
                                .executes(c -> ask(c.getSource(), StringArgumentType.getString(c, "message"))))));
    }

    private static AiBuddyEntity need(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        AiBuddyEntity b = AiBuddyMod.findBuddy(p, true);
        if (b == null) src.sendFailure(Component.literal("You don't have a buddy nearby. Use /ai spawn."));
        return b;
    }

    private static int spawn(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        if (AiBuddyMod.findBuddy(p, true) != null) {
            src.sendFailure(Component.literal("You already have a buddy. Use /ai come to bring it to you."));
            return 0;
        }
        AiBuddyEntity e = AiBuddyMod.BUDDY.get().create(p.serverLevel());
        if (e == null) return 0;
        e.moveTo(p.getX() + 1.0D, p.getY(), p.getZ(), p.getYRot(), 0.0F);
        e.setOwner(p.getUUID());
        p.serverLevel().addFreshEntity(e);
        AiBuddyMod.BUDDIES.put(p.getUUID(), e);
        e.mind.say("Hi " + p.getName().getString() + "! Talk to me with \"" + AiBuddyConfig.CHAT_PREFIX.get() + " <message>\" or /ai ask <message>.");
        return 1;
    }

    private static int dismiss(CommandSourceStack src) throws CommandSyntaxException {
        AiBuddyEntity b = need(src);
        if (b == null) return 0;
        b.stopAll();
        b.dropInventory();
        AiBuddyMod.BUDDIES.remove(src.getPlayerOrException().getUUID());
        b.discard();
        src.sendSuccess(() -> Component.literal("Buddy dismissed (its items were dropped)."), false);
        return 1;
    }

    private static int come(CommandSourceStack src) throws CommandSyntaxException {
        AiBuddyEntity b = need(src);
        if (b == null) return 0;
        ServerPlayer p = src.getPlayerOrException();
        if (b.level() != p.level()) {
            src.sendFailure(Component.literal("Your buddy is in another dimension."));
            return 0;
        }
        b.stopAll();
        b.teleportNear(p.blockPosition());
        return 1;
    }

    private static int stop(CommandSourceStack src) throws CommandSyntaxException {
        AiBuddyEntity b = need(src);
        if (b == null) return 0;
        b.stopAll();
        src.sendSuccess(() -> Component.literal("Buddy stopped everything."), false);
        return 1;
    }

    private static int forget(CommandSourceStack src) throws CommandSyntaxException {
        AiBuddyEntity b = need(src);
        if (b == null) return 0;
        b.mind.clearHistory();
        src.sendSuccess(() -> Component.literal("Buddy's conversation memory cleared."), false);
        return 1;
    }

    private static int status(CommandSourceStack src) throws CommandSyntaxException {
        AiBuddyEntity b = need(src);
        if (b == null) return 0;
        String s = "Buddy at " + b.blockPosition().toShortString() + " | health " + (int) b.getHealth() + "/" + (int) b.getMaxHealth()
                + " | food " + b.getFood() + "/20 | doing: " + b.describeCurrent() + " (" + b.queuedActions() + " queued)"
                + " | inventory: " + b.summarizeInventory();
        src.sendSuccess(() -> Component.literal(s), false);
        return 1;
    }

    private static int ask(CommandSourceStack src, String msg) throws CommandSyntaxException {
        AiBuddyEntity b = need(src);
        if (b == null) return 0;
        b.mind.ask(src.getPlayerOrException(), msg);
        return 1;
    }
}
