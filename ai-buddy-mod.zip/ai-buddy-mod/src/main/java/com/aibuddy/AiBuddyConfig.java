package com.aibuddy;

import net.minecraftforge.common.ForgeConfigSpec;

/** Written to config/aibuddy-common.toml on first launch. */
public final class AiBuddyConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.ConfigValue<String> PROVIDER;
    public static final ForgeConfigSpec.ConfigValue<String> API_URL;
    public static final ForgeConfigSpec.ConfigValue<String> API_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> TOKEN_PARAM;
    public static final ForgeConfigSpec.DoubleValue TEMPERATURE;
    public static final ForgeConfigSpec.IntValue MAX_TOKENS;
    public static final ForgeConfigSpec.IntValue TIMEOUT_SECONDS;

    public static final ForgeConfigSpec.ConfigValue<String> BUDDY_NAME;
    public static final ForgeConfigSpec.ConfigValue<String> CHAT_PREFIX;
    public static final ForgeConfigSpec.ConfigValue<String> EXTRA_PROMPT;
    public static final ForgeConfigSpec.IntValue HISTORY;
    public static final ForgeConfigSpec.IntValue MAX_AUTO_STEPS;
    public static final ForgeConfigSpec.IntValue MAX_ACTIONS;

    public static final ForgeConfigSpec.IntValue MAX_BUILD_BLOCKS;
    public static final ForgeConfigSpec.IntValue BUILD_DELAY;
    public static final ForgeConfigSpec.IntValue SCAN_RADIUS;
    public static final ForgeConfigSpec.IntValue MINE_RADIUS;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_MATERIALS;
    public static final ForgeConfigSpec.BooleanValue TELEPORT_FALLBACK;
    public static final ForgeConfigSpec.BooleanValue HUNGER;
    public static final ForgeConfigSpec.BooleanValue AUTO_DEFEND;
    public static final ForgeConfigSpec.BooleanValue BREAK_CONTAINERS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Which AI to talk to").push("llm");
        PROVIDER = b.comment("\"openai\" = any OpenAI-compatible chat API (OpenAI, OpenRouter, Groq, Gemini's compat endpoint, Ollama, LM Studio...).",
                "\"anthropic\" = Anthropic Messages API.")
                .define("provider", "openai");
        API_URL = b.comment("Full endpoint URL. Leave empty for the provider default.",
                "Ollama (free, local): http://localhost:11434/v1/chat/completions",
                "OpenRouter: https://openrouter.ai/api/v1/chat/completions")
                .define("apiUrl", "");
        API_KEY = b.comment("API key. Alternatively set the environment variable AIBUDDY_API_KEY. Not needed for local servers like Ollama.")
                .define("apiKey", "");
        MODEL = b.comment("Model name, e.g. gpt-4o-mini, llama3.1, claude-sonnet-5-5 ...").define("model", "gpt-4o-mini");
        TOKEN_PARAM = b.comment("OpenAI-style token limit field. Some newer models need \"max_completion_tokens\". Empty = don't send.")
                .define("tokenParam", "max_tokens");
        TEMPERATURE = b.comment("-1 = don't send a temperature (recommended default).").defineInRange("temperature", -1.0D, -1.0D, 2.0D);
        MAX_TOKENS = b.defineInRange("maxTokens", 2000, 200, 16000);
        TIMEOUT_SECONDS = b.comment("How long to wait for the AI before giving up.").defineInRange("timeoutSeconds", 90, 5, 600);
        b.pop();

        b.comment("Buddy behaviour").push("buddy");
        BUDDY_NAME = b.define("name", "Buddy");
        CHAT_PREFIX = b.comment("Start a chat message with this to talk to your buddy, e.g. \"@ai build a small house\".").define("chatPrefix", "@ai");
        EXTRA_PROMPT = b.comment("Extra instructions appended to the AI's system prompt (personality, rules...).").define("extraPrompt", "");
        HISTORY = b.comment("How many past messages (user+assistant) the AI remembers.").defineInRange("historyMessages", 14, 2, 60);
        MAX_AUTO_STEPS = b.comment("Max times the AI may call itself again after finishing actions, per player message.").defineInRange("maxAutoSteps", 12, 0, 100);
        MAX_ACTIONS = b.comment("Max actions accepted from one AI reply.").defineInRange("maxActionsPerReply", 60, 1, 500);
        REQUIRE_MATERIALS = b.comment("false = placing blocks is free (creative-style building). true = building/crafting uses items from the buddy's inventory.")
                .define("requireMaterials", false);
        HUNGER = b.comment("Buddy gets hungry and eats food from its inventory.").define("hunger", true);
        AUTO_DEFEND = b.comment("Buddy fights nearby hostile mobs on its own.").define("autoDefend", true);
        TELEPORT_FALLBACK = b.comment("If the buddy gets stuck walking somewhere, teleport it to a standing spot nearby.").define("teleportWhenStuck", true);
        BREAK_CONTAINERS = b.comment("Allow breaking chests, furnaces, spawners and other block entities.").define("breakContainers", false);
        b.pop();

        b.comment("World interaction").push("world");
        MAX_BUILD_BLOCKS = b.comment("Max blocks in one fill action.").defineInRange("maxBuildBlocks", 8000, 1, 200000);
        BUILD_DELAY = b.comment("Ticks between placed blocks (lower = faster building).").defineInRange("buildDelayTicks", 2, 1, 40);
        SCAN_RADIUS = b.comment("How far around the buddy the AI is told about blocks.").defineInRange("scanRadius", 14, 4, 32);
        MINE_RADIUS = b.comment("How far the buddy searches for blocks to mine.").defineInRange("mineRadius", 20, 4, 48);
        b.pop();

        SPEC = b.build();
    }

    private AiBuddyConfig() {}
}
